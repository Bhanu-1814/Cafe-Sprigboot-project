package com.foods.OrderService.service;

import com.foods.OrderService.data.Order;
import com.foods.OrderService.data.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;


    public List<Order> getOrder() {
        return orderRepository.findAll();
    }

    public Order registerOrder(Order order) {
        return orderRepository.save(order);
    }



    public Optional<Order> updateOrder(Integer id, Order updatedOrder) {
        Optional<Order> orderOptional = orderRepository.findById(id);
        if (orderOptional.isPresent()) {
            Order existingOrder = orderOptional.get();
            existingOrder.setName(updatedOrder.getName());
            existingOrder.setEmail(updatedOrder.getEmail());
            existingOrder.setGuestcount(updatedOrder.getGuestcount());
            existingOrder.setPhone(updatedOrder.getPhone());
            existingOrder.setOrdertype(updatedOrder.getOrdertype());
            return Optional.of(orderRepository.save(existingOrder));
        }
        return Optional.empty();
    }

    public boolean deleteOrder(Integer id) {
        if (orderRepository.existsById(id)) {
            orderRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
