package com.foods.OrderService.config;

public class WebConfig {
}
