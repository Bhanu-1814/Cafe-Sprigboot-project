package com.foods.OrderService.controller;

import com.foods.OrderService.data.Order;
import com.foods.OrderService.data.OrderRepository;
import com.foods.OrderService.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService userService;

    @PostMapping("/order")
    public ResponseEntity<?> registerOrder(@RequestBody Order order) {
        Order newOrder = userService.registerOrder(order);
        return ResponseEntity.ok(newOrder);
    }

    @Autowired
    private OrderRepository userRepository;

    @GetMapping("/")
    public List<Order> getAllOrders() {
        return userService.getOrder();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editOrder(@PathVariable int id, @RequestBody Order updatedOrder) {
        Optional<Order> user = userService.updateOrder(id, updatedOrder);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            return ResponseEntity.status(404).body("Order not found");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteOrder(@PathVariable int id) {
        boolean deleted = userService.deleteOrder(id);
        if (deleted) {
            return ResponseEntity.ok("Order deleted successfully");
        } else {
            return ResponseEntity.status(404).body("Order not found");
        }
    }

}