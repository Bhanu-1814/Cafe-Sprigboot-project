package com.foods.FeedbackService.service;

import com.foods.FeedbackService.data.Feedback;
import com.foods.FeedbackService.data.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class FeedbackService {
    @Autowired
    private FeedbackRepository feedbackRepository;

    //private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public Feedback registerFeedback(Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    public Optional<Feedback> updateFeedback(int id, Feedback updatedFeedback) {
        Optional<Feedback> feedbackOptional = feedbackRepository.findById(id);
        if (feedbackOptional.isPresent()) {
            Feedback existingFeedback = feedbackOptional.get();
            existingFeedback.setName(updatedFeedback.getName());
            existingFeedback.setEmail(updatedFeedback.getEmail());
            return Optional.of(feedbackRepository.save(existingFeedback));
        } else {
            return Optional.empty();
        }
    }

    public boolean deleteFeedback(int id) {
        Optional<Feedback> feedbackOptional = feedbackRepository.findById(id);
        if (feedbackOptional.isPresent()) {
            feedbackRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}
