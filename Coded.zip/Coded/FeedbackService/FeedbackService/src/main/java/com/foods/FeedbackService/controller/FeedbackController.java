package com.foods.FeedbackService.controller;


import com.foods.FeedbackService.data.Feedback;
import com.foods.FeedbackService.data.FeedbackRepository;
import com.foods.FeedbackService.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/feedbacks")
public class FeedbackController {
    @Autowired
    private FeedbackService feedbackService;

    @PostMapping("/feedback")
    public ResponseEntity<?> registerFeedback(@RequestBody Feedback feedback) {
        Feedback newFeedback = feedbackService.registerFeedback(feedback);
        return ResponseEntity.ok(newFeedback);
    }

    @Autowired
    private FeedbackRepository feedbackRepository;

    @GetMapping
    public List<Feedback> getAllFeedbacks() {
        return feedbackRepository.findAll();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> editFeedback(@PathVariable int id, @RequestBody Feedback updatedFeedback) {
        Optional<Feedback> feedback = feedbackService.updateFeedback(id, updatedFeedback);
        if (feedback.isPresent()) {
            return ResponseEntity.ok(feedback.get());
        } else {
            return ResponseEntity.status(404).body("Feedback not found");
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFeedback(@PathVariable int id) {
        boolean deleted = feedbackService.deleteFeedback(id);
        if (deleted) {
            return ResponseEntity.ok("Feedback deleted successfully");
        } else {
            return ResponseEntity.status(404).body("Feedback not found");
        }
    }
}
