package com.foods.UserService.config;

public class WebConfig {
}
